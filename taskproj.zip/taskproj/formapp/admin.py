from django.contrib import admin
from formapp.models import *
# Register your models here.
admin.site.register(Profile)
