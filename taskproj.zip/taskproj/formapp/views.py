from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpRequest
from django.contrib import messages
from . forms import Regform
from . models import*
# Create your views here.
def register(request):
        form=Regform()
        return render(request,'formapp/djform.html',{'form':form})

def data(request):
    age=request.GET['age']
    gender=request.GET['gender']
    name=request.GET['name']
    import sqlite3 as s
    con=s.connect('test.db')
    cur=con.cursor()
    cur.execute('create table if not exists t1(name varchar2(20),age integer,gender varchar2(10))')
    cur.execute('insert into t1 values(?,?,?)',(name,age,gender))
    cur.execute('select * from t1')
    cur.execute('commit')
    data=cur.fetchall()
    con.close()
    Profile.objects.get_or_create(name=name,age=age,gender=gender)
    udata=Profile.objects.all()
    dict={'name':name,'gender':gender,'age':age}
    messages.success(request,f'ENTERED YOUR DATA {name}')
    return render(request,'formapp/data.html',{'dict':dict,'data':data,'udata':udata})
def home(request):
    return render(request,'formapp/home.html')
def display(request):
        return render(request,'formapp/myform.html')
