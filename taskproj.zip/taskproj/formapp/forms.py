from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
class Regform(UserCreationForm):
    name=forms.CharField(required=True)
    age=forms.IntegerField()
    gender=forms.CharField()
    class Meta:
        model=User
        fields=['name','age','gender']
    #def save(self,commit=True):
